def lambda_handler(event, context):
    # Passa por cada registro enviado pela fila do SQS
    for record in event['Records']:
        pedido = record['body']
        # O comando print envia automaticamente o log para o CloudWatch Logs
        print(f"PROCESSAMENTO CONCLUIDO -> Mensagem recebida do SQS: {pedido}")
    return {'statusCode': 200}
